#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <fcntl.h>
void filescan(FILE *f,int *n,int *m,float A[][20])
{
	int i=-1,j=0;
	char *record,*line,buffer[1000] ;
	while((line=fgets(buffer,sizeof(buffer),f))!=NULL)   
	{ 
		record = strtok(line,","); 
		j=0;    
		while(record != NULL)     
		{    
			if(i>=0)    
				A[i][j++] = atof(record) ;     
			record = strtok(NULL,",");     
		}  
		*m=j;   
		i++ ;   
	}
	*n=i;
}
int no_neurons=8;
int no_classes=10;
float learning_rate=0.001;
int flag=1;

float random_weight()
{
	return (((float)rand()/((float)RAND_MAX+1)));
}
float sigmoid_function(float x)
{
	return (float)((1.0)/(1.0+exp(-1.0*x)));
}
float max(int number,float array[])
{
	int i,index;
	float max;
	max=array[0];
	for(i=0;i<number;i++)
	{
		if(array[i]>max)
		{
			index=i;
			max=array[i];
		}
	}
	return index;
}

float multi_layer(float in_data[][20],int original_value[],float test_data[][20],int original_value2[],int n1,int n2)
{
	int i,j,k,l,count=0,t,g,class,c,s;
	float neuron_array_test[100],class_array_test[100],a,eta=0.001;
	float delta[100],dummy[2500][2],del_weight,dw=0.0000,wt,result=0.00000,result1=0.0000,neuron_array[100],class_array[100],error,error_array[100],weight_array1[100][100],weight_array2[100][100],final_weight_array1[100][100],final_weight_array2[100][100],neuron_array_update[100],class_array_update[100];
	float w=1;
	while((float)w>0.0001*eta)
	{
		for(s=0;s<2;s++)
		{

			for(j=0;j<no_neurons;j++)
			{
				result=0.000;
				for(i=0;i<17;i++)
				{
					if(g==0)
					{
						weight_array1[j][i]=(random_weight()-0.5);
						//printf("%f ",weight_array1[j][i]);
					}
					result=result+(in_data[s][i]*weight_array1[j][i]);
				}
				neuron_array[j]=sigmoid_function(result);
				neuron_array_update[j]=neuron_array[j]*(1-neuron_array[j]);
			}
			for(i=0;i<no_classes;i++)
			{
				result=0.00;
				for(j=0;j<no_neurons;j++)
				{
					if(g==0)
						weight_array2[i][j]=(random_weight()-0.5);
					result+=neuron_array[j]*weight_array2[i][j];
				}
				class_array[i]=sigmoid_function(result);
				class_array_update[i]=class_array[i]*(1-class_array[i]);
				dummy[s][i]=0.0;
			}
			c=original_value[s];
			dummy[s][c-1]=1;

			for(i=0;i<no_classes;i++)
			{
				error_array[i]=dummy[s][i]-class_array[i];
				error+=0.5*((dummy[s][i]-class_array[i])*(dummy[s][i]-class_array[i]));
			}

			for(k=0;k<no_classes;k++)
			{
				for(l=0;l<no_neurons;l++)
				{
					del_weight=(error_array[k])*(neuron_array[l])*(learning_rate);
					weight_array2[k][l]=weight_array2[k][l]+del_weight;

				}
			}
			for(i=0;i<no_neurons;i++)
			{
				for(j=0;j<no_classes;j++)
				{
					dw= dw +((error_array[j])* (weight_array2[j][i])* (neuron_array_update[i]));
				}
				delta[i]=dw;
			}
			//c=9;
			for(i=0;i<no_neurons;i++)
			{
				for(k=0;k<17;k++)
				{	
					weight_array1[i][k]=weight_array1[i][k]+((learning_rate)*(in_data[s][k])*(delta[i]));
					w=weight_array1[i][k];
				}
			}

		}
	}
	/*for(i=0;i<17;i++)
	{
		for(j=0;j<no_neurons;j++)
		{
			printf("%f ",weight_array1[j][i]);
		}
		printf("\n");
	}*/
	count=0;
	for(s=0;s<n2;s++)
	{
		for(j=0;j<no_neurons;j++)
		{
			result1=0.000;
			for(i=0;i<17;i++)
			{
				wt=weight_array1[j][i];
				result1=result1+(test_data[s][i]*wt);
			}
			neuron_array_test[j]=sigmoid_function(result1);
		}
		for(i=0;i<no_classes;i++)
		{
			result1=0.000;
			for(j=0;j<no_neurons;j++)
			{
				wt=weight_array2[i][j];
				result1+=neuron_array_test[j]*wt;
			}
			class_array_test[i]=sigmoid_function(result1);
		}
		class=max(no_classes,class_array_test);
		if(original_value2[s]==class+1)
			count++;
	}
	printf("accuracy %f\n",(float)count/n2*100.0); 
}

int main()
{
	srand(time(NULL));
	int i,j,original_value,original_value1[2500],original_value2[2500],n1,m1,n2,m2;
	float in_data[2500][20],test_data[2500][20];
	FILE *fp,*test;
	fp=fopen("train1.csv","r");
	test=fopen("test.csv","r");
	filescan(fp,&n1,&m1,in_data);
	filescan(test,&n2,&m2,test_data);

	for(i=0;i<n1;i++)
	{	
		original_value1[i]=in_data[i][0];
		in_data[i][0]=1;
	}
	for(i=0;i<n2;i++)
	{	
		original_value2[i]=test_data[i][0];
		test_data[i][0]=1;
	}
	multi_layer(in_data,original_value1,test_data,original_value2,n1,n2);
	//printf("accuracy is %f%\n",a);
	fclose(fp);
	fclose(test);
	return 0;
}
